<!-- INSTRUCTION: Complete the information below from your Administration page -->

Rocket.Chat Version: 
Running Instances: 
DB Replicaset OpLog:
Node Version:
