export ROCKET_DEPLOY_DIR="/tmp/deploy"
mkdir -p $ROCKET_DEPLOY_DIR
