Template.registerHelper('not', (value) => {
	return !value;
});
