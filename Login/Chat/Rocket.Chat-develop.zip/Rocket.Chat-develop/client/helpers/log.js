Template.registerHelper('log', () => {
	console.log.apply(console, arguments);
});
