this.ChatIntegrations = new Mongo.Collection('rocketchat_integrations');
this.ChatIntegrationHistory = new Mongo.Collection('rocketchat_integration_history');
