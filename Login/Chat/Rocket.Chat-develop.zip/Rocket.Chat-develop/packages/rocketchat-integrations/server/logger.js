/* globals logger:true */
/* exported logger */

logger = new Logger('Integrations', {
	sections: {
		incoming: 'Incoming WebHook',
		outgoing: 'Outgoing WebHook'
	}
});
