/* globals Importer */
Importer.addImporter('slack', Importer.Slack, {
	name: 'Slack',
	mimeType: 'application/zip'
});
