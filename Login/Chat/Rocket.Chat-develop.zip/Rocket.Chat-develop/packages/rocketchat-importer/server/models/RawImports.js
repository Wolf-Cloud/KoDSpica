/* globals Importer */
Importer.RawImports = new (Importer.RawImports = class RawImports extends RocketChat.models._Base {
	constructor() {
		super('raw_imports');
	}
});
