/* globals Importer */
Importer.Imports = new (Importer.Imports = class Imports extends RocketChat.models._Base {
	constructor() {
		super('import');
	}
});
