/* globals Importer */

Importer.addImporter('hipchat', Importer.HipChat, {
	name: 'HipChat',
	mimeType: 'application/zip'
});
